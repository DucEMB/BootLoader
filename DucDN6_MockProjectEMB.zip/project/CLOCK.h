#ifndef CLOCK_H
#define CLOCK_H

#include "LIB.h"
#include "MKL46Z4.h"

/*************************************************/
void SetCoreClockPLL(uint32 Frequency);

/********************** PROTOTYPE ************************/
#endif
